<template>
    <div class="home">
        <div class="container">
            <h1 class="title">文华云网盘</h1>
            <p class="lead"> 专注于线上云储存，资源云分享 </p>
        </div>
    </div>
</template>

<style scoped>
.home {
  width: 100%;
  height: 100%;
  background: url(../assets/bg2.jpg) no-repeat;
  background-size: 100% 100%;
}
.container {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  padding-top: 100px;
  background-color: rgba(0, 0, 0, 0.7);
  text-align: center;
  color: white;
}
.title {
  font-size: 30px;
}
.lead {
  margin-top: 50px;
  font-size: 22px;
}
</style>