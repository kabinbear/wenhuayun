<template>
    <div>
      "
© 2018 引航工作室 友情链接：  
      "
     <a href="http://www.hustwenhua.net/">文华学院</a>
     <a href="http://xinxi.hustwenhua.net/">文华学院信息科学与技术学部</a>
    </div>
</template>
<script>
export default {
  name:Footer
}
</script>
