module.exports = {
  mongoURI:
    'mongodb://nodevueelement:test1234@ds143717.mlab.com:43717/node-vue-element',
  secretOrKey: 'secret'
};
